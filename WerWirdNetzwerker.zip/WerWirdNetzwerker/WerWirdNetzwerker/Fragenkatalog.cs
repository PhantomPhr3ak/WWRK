﻿using System;
using System.Collections.Generic;
using System.IO;
using System.Linq;
using System.Runtime.InteropServices;
using Excel = Microsoft.Office.Interop.Excel;       //Microsoft Excel 14 object in references-> COM tab

namespace WerWirdNetzwerker
{
    class Fragenkatalog
    {
      
        List<Frage>[] katalog = new List<Frage>[12];
        Random der_zufall = new Random();
        public int debug = 0;
        Form1 parent;

        public Fragenkatalog(Form1 _parent)
        {
            parent = _parent;
            for (int i = 0; i < 12; i++)
            {
                katalog[i] = new List<Frage>();
            }

            string folderpath =Path.Combine(Environment.CurrentDirectory, "Files\\");

            string[] files = Directory.GetFiles(folderpath, "*", SearchOption.TopDirectoryOnly);
            for (int i = 0; i < files.Length; i++)
            {
                string filename = files[i];
                readExcelFile(filename);
            }
        }

        public Frage stelleFrage(int stufenNummer)
        {
            int zufallsNummer = der_zufall.Next(0,katalog[stufenNummer].Count());
            Frage zuStellen = katalog[stufenNummer].ElementAt(zufallsNummer);
            return zuStellen;
        }

        void readExcelFile(string @filename)
        {
            if (filename.Contains('~'))
                return;
            //Create COM Objects. Create a COM object for everything that is referenced
            Excel.Application xlApp = new Excel.Application();
            Excel.Workbook xlWorkbook = xlApp.Workbooks.Open(@filename);
            Excel._Worksheet xlWorksheet = xlWorkbook.Sheets[1];
            Excel.Range xlRange = xlWorksheet.UsedRange;
            int spalten = xlRange.Columns.Count;
            int zeilen = xlRange.Rows.Count;

            //parent.writeBox("Inhalt: " + xlRange.Cells[1, 2].Value);

            try
            {
                for (int zeile = 1; zeile <= zeilen; zeile++)
                {
                    if (xlRange.Cells[zeile, 6].Value != null)
                    {
                        int fragenstufe = Convert.ToInt32(xlRange.Cells[zeile, 6].Value) - 1;
                        string fragentext = "" + xlRange.Cells[zeile, 1].Value;
                        string tipp = "" + xlRange.Cells[zeile, 7].Value;
                        string quelle = "" + xlRange.Cells[zeile, 8].Value;
                        string[] antworten = new string[4];
                        antworten[0] = "" + xlRange.Cells[zeile, 2].Value;
                        antworten[1] = "" + xlRange.Cells[zeile, 3].Value;
                        antworten[2] = "" + xlRange.Cells[zeile, 4].Value;
                        antworten[3] = "" + xlRange.Cells[zeile, 5].Value;

                        if (fragenstufe != -1)
                        {
                            katalog[fragenstufe].Add(
                                new Frage(fragentext, antworten, fragenstufe, tipp, quelle));
                        }
                    }
                }
            }
            catch (Exception ex)
            {
                Console.Write(ex.Message);
            }
            finally
            {
                //cleanup
                GC.Collect();
                GC.WaitForPendingFinalizers();
                Marshal.ReleaseComObject(xlRange);
                Marshal.ReleaseComObject(xlWorksheet);
                xlWorkbook.Close();
                Marshal.ReleaseComObject(xlWorkbook);
                xlApp.Quit();
                Marshal.ReleaseComObject(xlApp);
            }
        }
    }
}
