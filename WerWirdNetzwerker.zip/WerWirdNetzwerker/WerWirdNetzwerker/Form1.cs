﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace WerWirdNetzwerker
{
    public partial class Form1 : Form
    {
        Fragenkatalog die_fragen;
        int aktuelle_stufe = 0;
        Frage aktuelle_frage;
        int anzahl_versuche = 1;
        Random derZufall = new Random();
        Button[] antwortButtons = new Button[4];
        bool tippMoeglich = true;

        public Form1()
        {
            InitializeComponent();
            antwortButtons[0] = btn_ant_1;
            antwortButtons[1] = btn_ant_2;
            antwortButtons[2] = btn_ant_3;
            antwortButtons[3] = btn_ant_4;

            die_fragen = new Fragenkatalog(this);

            setupGame();
        }

        void setupGame()
        {
            aktuelle_stufe = 0;
            pbr_stufe.Value = aktuelle_stufe;
            grpbx_frage.Text = (aktuelle_stufe + 1) + ". Frage";
            loadFrage();
            btn_tipp.Enabled = true;
            btn_5050.Enabled = true;
            tippMoeglich = true;
        }

        void loadFrage()
        {
            aktuelle_frage = die_fragen.stelleFrage(aktuelle_stufe);

            lbl_frage.Text = aktuelle_frage.Fragentext;
            btn_ant_1.Text = aktuelle_frage.Antworten[0];
            btn_ant_2.Text = aktuelle_frage.Antworten[1];
            btn_ant_3.Text = aktuelle_frage.Antworten[2];
            btn_ant_4.Text = aktuelle_frage.Antworten[3];

            for (int i = 0; i < antwortButtons.Length; i++)
            {
                antwortButtons[i].Enabled = true;
            }

            if(aktuelle_frage.Quelle == "")
            {
                btn_quelle.Enabled = false;
            }
            else
            {
                btn_quelle.Enabled = true;
            }

            if (aktuelle_frage.Tipp == "")
            {
                btn_tipp.Enabled = false;
            }
            else
            {
                if(tippMoeglich)
                    btn_tipp.Enabled = true;
            }
        }

        public void writeBox(string inhalt)
        {
            MessageBox.Show(inhalt);
        }

        void istAntwortKorrekt(object sender)
        {
            bool antwortIst = false;

            Button senderButton = sender as Button;
            string buttonName = senderButton.Name;
            int buttonID = Convert.ToInt32( buttonName.Split('_')[2] );
            buttonID--;

            if (aktuelle_frage.RichtigeAntwort == buttonID)
                antwortIst = true;

            if (antwortIst)
            {
                if(!nächsteStufe())
                    MessageBox.Show("Diese Antwort ist Richtig.\nEs geht zur nächsten Frage der Stufe: " + (aktuelle_stufe + 1));
            }
            else
            {
                string verliererString = "Leider Falsch!\n";
                verliererString += "Als richtige Antwort wurde angegeben:\n" + aktuelle_frage.Antworten[aktuelle_frage.RichtigeAntwort] + "\n\n";
                if(aktuelle_frage.Quelle != "")
                {
                    verliererString += "Falls Sie die Quelle überprüfen möchten, diese Quelle wurde angegeben:\n" + aktuelle_frage.Quelle + "\n";
                }
                else
                {
                    verliererString += "Es wurde keine Quelle für die Frage angegeben.\n";
                }

                verliererString += "Dies war Ihr " + anzahl_versuche + ". Versuch. Das Spiel wird neu gestartet. Viel Erfolg.";
                MessageBox.Show(verliererString);
                anzahl_versuche++;
                setupGame();
            }
        }

        bool nächsteStufe()
        {
            bool spielBeendet = false;
            aktuelle_stufe++;
            if (aktuelle_stufe < 12)
            {
                pbr_stufe.Value = aktuelle_stufe;
                grpbx_frage.Text = (aktuelle_stufe + 1) + ". Frage";
                loadFrage();
            }
            else if (aktuelle_stufe >= 12)
            {
                spielBeendet = true;
                spielGewonnen();
            }

            return spielBeendet;
        }

        void spielGewonnen()
        {
            MessageBox.Show("Herzlichen Glückwunsch. Sie haben alle 12 Fragen richtig beantwortet. Dafür haben Sie " + anzahl_versuche
                + " Versuche gebraucht.\n\nEs wird automatisch ein neues Spiel gestartet.");
            setupGame();
        }

        private void btn_ant_1_Click(object sender, EventArgs e)
        {
            istAntwortKorrekt(sender);
        }

        private void btn_ant_2_Click(object sender, EventArgs e)
        {
            istAntwortKorrekt(sender);
        }

        private void btn_ant_3_Click(object sender, EventArgs e)
        {
            istAntwortKorrekt(sender);
        }

        private void btn_ant_4_Click(object sender, EventArgs e)
        {
            istAntwortKorrekt(sender);
        }

        private void btn_tipp_Click(object sender, EventArgs e)
        {
            MessageBox.Show("Der oder die Autoren geben folgenden Tipp:\n" + aktuelle_frage.Tipp);
            if (aktuelle_frage.Tipp != "")
            {
                btn_tipp.Enabled = false;
                tippMoeglich = false;
            }
        }

        private void btn_5050_Click(object sender, EventArgs e)
        {
            int deaktivierteButtons = 0, testeButton;
            while (deaktivierteButtons < 2)
            {
                testeButton = derZufall.Next(0, 4);
                if (testeButton != aktuelle_frage.RichtigeAntwort && antwortButtons[testeButton].Enabled == true)
                {
                    antwortButtons[testeButton].Enabled = false;
                    deaktivierteButtons++;
                }
            }
            btn_5050.Enabled = false;
        }

        private void btn_quelle_Click(object sender, EventArgs e)
        {
            MessageBox.Show("Folgende Quelle wurde angegeben:\n" + aktuelle_frage.Quelle);
        }
    }
}
