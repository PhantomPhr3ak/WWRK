﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace WerWirdNetzwerker
{
    class Frage
    {
        string fragentext = "DEFAULT_FRAGENTEXT";
        string[] antworten = {
        "DEFAULT_RICHTIGE_ANTWORT",
        "DEFAULT_FALSCHE_ANTWORT",
        "DEFAULT_FALSCHE_ANTWORT",
        "DEFAULT_FALSCHE_ANTWORT"};
        int stufe = -1;
        int richtigeAntwort = -1;
        string tipp = "DEFAULT_TIPP_TEXT";
        string quelle = "DEFAULT_QUELLEN_TEXT";
        Random derZufall = new Random();

        #region Getter und Setter

        public string Fragentext
        {
            get { return fragentext; }
            set { fragentext = value; }
        }
        public string[] Antworten
        {
            get { return antworten; }
            set { antworten = value; }
        }

        public int Stufe
        {
            get { return stufe; }
            set { stufe = value; }
        }
        public string Tipp
        {
            get { return tipp; }
            set { tipp = value; }
        }
        public string Quelle
        {
            get { return quelle; }
            set { quelle = value; }
        }

        public int RichtigeAntwort
        {
            get
            {
                return richtigeAntwort;
            }

            set
            {
                richtigeAntwort = value;
            }
        }
        #endregion

        public Frage(
            string _fragentext,
            string[] _antworten,
            int _stufe,
            string _tipp,
            string _quelle)
        {
            fragentext = _fragentext;
            antworten = _antworten;
            stufe = _stufe;
            tipp = _tipp;
            quelle = _quelle;

            mischeAntworten();
        }

        void mischeAntworten()
        {
            bool allesGemischt = false;
            int counter = 0, neuerIndex = 0;
            int anzahlFragen = 4;
            int[] transposition = new int[4];

            for (int i = 0; i < transposition.Length; i++)
            {
                transposition[i] = -1;
            }

            while(!allesGemischt)
            {
                neuerIndex = derZufall.Next(0, anzahlFragen);
                if(transposition[neuerIndex] == -1)
                {
                    if (richtigeAntwort == -1)
                    {
                        richtigeAntwort = neuerIndex;
                    }

                    transposition[neuerIndex] = counter;
                    counter++;
                }

                if (counter == 4)
                    allesGemischt = true;
            }

            string[] antwortenCache = new string[4];

            for (int i = 0; i < transposition.Length; i++)
            {
                antwortenCache[i] = antworten[transposition[i]];
            }

            copyCache(antwortenCache);
        }

        void copyCache(string[] cache)
        {
            for (int i = 0; i < cache.Length; i++)
            {
                antworten[i] = cache[i];
            }
        }
    }
}
