﻿namespace WerWirdNetzwerker
{
    partial class Form1
    {
        /// <summary>
        /// Erforderliche Designervariable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Verwendete Ressourcen bereinigen.
        /// </summary>
        /// <param name="disposing">True, wenn verwaltete Ressourcen gelöscht werden sollen; andernfalls False.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Vom Windows Form-Designer generierter Code

        /// <summary>
        /// Erforderliche Methode für die Designerunterstützung.
        /// Der Inhalt der Methode darf nicht mit dem Code-Editor geändert werden.
        /// </summary>
        private void InitializeComponent()
        {
            this.grpbx_frage = new System.Windows.Forms.GroupBox();
            this.lbl_frage = new System.Windows.Forms.Label();
            this.btn_ant_1 = new System.Windows.Forms.Button();
            this.tableLayoutPanel1 = new System.Windows.Forms.TableLayoutPanel();
            this.btn_ant_4 = new System.Windows.Forms.Button();
            this.btn_ant_3 = new System.Windows.Forms.Button();
            this.btn_ant_2 = new System.Windows.Forms.Button();
            this.pbr_stufe = new System.Windows.Forms.ProgressBar();
            this.tableLayoutPanel2 = new System.Windows.Forms.TableLayoutPanel();
            this.btn_5050 = new System.Windows.Forms.Button();
            this.btn_tipp = new System.Windows.Forms.Button();
            this.btn_quelle = new System.Windows.Forms.Button();
            this.grpbx_frage.SuspendLayout();
            this.tableLayoutPanel1.SuspendLayout();
            this.tableLayoutPanel2.SuspendLayout();
            this.SuspendLayout();
            // 
            // grpbx_frage
            // 
            this.grpbx_frage.Controls.Add(this.lbl_frage);
            this.grpbx_frage.Location = new System.Drawing.Point(15, 12);
            this.grpbx_frage.Name = "grpbx_frage";
            this.grpbx_frage.Size = new System.Drawing.Size(272, 72);
            this.grpbx_frage.TabIndex = 0;
            this.grpbx_frage.TabStop = false;
            this.grpbx_frage.Text = "Frage";
            // 
            // lbl_frage
            // 
            this.lbl_frage.Dock = System.Windows.Forms.DockStyle.Fill;
            this.lbl_frage.Location = new System.Drawing.Point(3, 16);
            this.lbl_frage.Name = "lbl_frage";
            this.lbl_frage.Size = new System.Drawing.Size(266, 53);
            this.lbl_frage.TabIndex = 0;
            this.lbl_frage.Text = "FRAGENTEXT";
            // 
            // btn_ant_1
            // 
            this.btn_ant_1.Location = new System.Drawing.Point(3, 3);
            this.btn_ant_1.Name = "btn_ant_1";
            this.btn_ant_1.Size = new System.Drawing.Size(133, 69);
            this.btn_ant_1.TabIndex = 1;
            this.btn_ant_1.Text = "button1";
            this.btn_ant_1.UseVisualStyleBackColor = true;
            this.btn_ant_1.Click += new System.EventHandler(this.btn_ant_1_Click);
            // 
            // tableLayoutPanel1
            // 
            this.tableLayoutPanel1.ColumnCount = 2;
            this.tableLayoutPanel1.ColumnStyles.Add(new System.Windows.Forms.ColumnStyle(System.Windows.Forms.SizeType.Percent, 50F));
            this.tableLayoutPanel1.ColumnStyles.Add(new System.Windows.Forms.ColumnStyle(System.Windows.Forms.SizeType.Percent, 50F));
            this.tableLayoutPanel1.Controls.Add(this.btn_ant_4, 1, 1);
            this.tableLayoutPanel1.Controls.Add(this.btn_ant_3, 0, 1);
            this.tableLayoutPanel1.Controls.Add(this.btn_ant_2, 1, 0);
            this.tableLayoutPanel1.Controls.Add(this.btn_ant_1, 0, 0);
            this.tableLayoutPanel1.Location = new System.Drawing.Point(12, 90);
            this.tableLayoutPanel1.Name = "tableLayoutPanel1";
            this.tableLayoutPanel1.RowCount = 2;
            this.tableLayoutPanel1.RowStyles.Add(new System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Percent, 50F));
            this.tableLayoutPanel1.RowStyles.Add(new System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Percent, 50F));
            this.tableLayoutPanel1.Size = new System.Drawing.Size(278, 150);
            this.tableLayoutPanel1.TabIndex = 2;
            // 
            // btn_ant_4
            // 
            this.btn_ant_4.Location = new System.Drawing.Point(142, 78);
            this.btn_ant_4.Name = "btn_ant_4";
            this.btn_ant_4.Size = new System.Drawing.Size(133, 69);
            this.btn_ant_4.TabIndex = 4;
            this.btn_ant_4.Text = "button4";
            this.btn_ant_4.UseVisualStyleBackColor = true;
            this.btn_ant_4.Click += new System.EventHandler(this.btn_ant_4_Click);
            // 
            // btn_ant_3
            // 
            this.btn_ant_3.Location = new System.Drawing.Point(3, 78);
            this.btn_ant_3.Name = "btn_ant_3";
            this.btn_ant_3.Size = new System.Drawing.Size(133, 69);
            this.btn_ant_3.TabIndex = 3;
            this.btn_ant_3.Text = "button3";
            this.btn_ant_3.UseVisualStyleBackColor = true;
            this.btn_ant_3.Click += new System.EventHandler(this.btn_ant_3_Click);
            // 
            // btn_ant_2
            // 
            this.btn_ant_2.Location = new System.Drawing.Point(142, 3);
            this.btn_ant_2.Name = "btn_ant_2";
            this.btn_ant_2.Size = new System.Drawing.Size(133, 69);
            this.btn_ant_2.TabIndex = 2;
            this.btn_ant_2.Text = "button2";
            this.btn_ant_2.UseVisualStyleBackColor = true;
            this.btn_ant_2.Click += new System.EventHandler(this.btn_ant_2_Click);
            // 
            // pbr_stufe
            // 
            this.pbr_stufe.Location = new System.Drawing.Point(15, 246);
            this.pbr_stufe.Maximum = 12;
            this.pbr_stufe.Name = "pbr_stufe";
            this.pbr_stufe.Size = new System.Drawing.Size(272, 23);
            this.pbr_stufe.Step = 2;
            this.pbr_stufe.TabIndex = 3;
            // 
            // tableLayoutPanel2
            // 
            this.tableLayoutPanel2.ColumnCount = 3;
            this.tableLayoutPanel2.ColumnStyles.Add(new System.Windows.Forms.ColumnStyle(System.Windows.Forms.SizeType.Percent, 33.33333F));
            this.tableLayoutPanel2.ColumnStyles.Add(new System.Windows.Forms.ColumnStyle(System.Windows.Forms.SizeType.Percent, 33.33333F));
            this.tableLayoutPanel2.ColumnStyles.Add(new System.Windows.Forms.ColumnStyle(System.Windows.Forms.SizeType.Percent, 33.33333F));
            this.tableLayoutPanel2.Controls.Add(this.btn_5050, 1, 0);
            this.tableLayoutPanel2.Controls.Add(this.btn_tipp, 0, 0);
            this.tableLayoutPanel2.Controls.Add(this.btn_quelle, 2, 0);
            this.tableLayoutPanel2.Location = new System.Drawing.Point(12, 275);
            this.tableLayoutPanel2.Name = "tableLayoutPanel2";
            this.tableLayoutPanel2.RowCount = 1;
            this.tableLayoutPanel2.RowStyles.Add(new System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Percent, 100F));
            this.tableLayoutPanel2.Size = new System.Drawing.Size(278, 47);
            this.tableLayoutPanel2.TabIndex = 4;
            // 
            // btn_5050
            // 
            this.btn_5050.Location = new System.Drawing.Point(95, 3);
            this.btn_5050.Name = "btn_5050";
            this.btn_5050.Size = new System.Drawing.Size(86, 41);
            this.btn_5050.TabIndex = 1;
            this.btn_5050.Text = "50 / 50";
            this.btn_5050.UseVisualStyleBackColor = true;
            this.btn_5050.Click += new System.EventHandler(this.btn_5050_Click);
            // 
            // btn_tipp
            // 
            this.btn_tipp.Location = new System.Drawing.Point(3, 3);
            this.btn_tipp.Name = "btn_tipp";
            this.btn_tipp.Size = new System.Drawing.Size(86, 41);
            this.btn_tipp.TabIndex = 0;
            this.btn_tipp.Text = "Tipp";
            this.btn_tipp.UseVisualStyleBackColor = true;
            this.btn_tipp.Click += new System.EventHandler(this.btn_tipp_Click);
            // 
            // btn_quelle
            // 
            this.btn_quelle.Location = new System.Drawing.Point(187, 3);
            this.btn_quelle.Name = "btn_quelle";
            this.btn_quelle.Size = new System.Drawing.Size(88, 41);
            this.btn_quelle.TabIndex = 2;
            this.btn_quelle.Text = "Quelle";
            this.btn_quelle.UseVisualStyleBackColor = true;
            this.btn_quelle.Click += new System.EventHandler(this.btn_quelle_Click);
            // 
            // Form1
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(302, 329);
            this.Controls.Add(this.tableLayoutPanel2);
            this.Controls.Add(this.pbr_stufe);
            this.Controls.Add(this.tableLayoutPanel1);
            this.Controls.Add(this.grpbx_frage);
            this.FormBorderStyle = System.Windows.Forms.FormBorderStyle.FixedSingle;
            this.MaximizeBox = false;
            this.Name = "Form1";
            this.Text = "Wer wird Netzwerker?";
            this.grpbx_frage.ResumeLayout(false);
            this.tableLayoutPanel1.ResumeLayout(false);
            this.tableLayoutPanel2.ResumeLayout(false);
            this.ResumeLayout(false);

        }

        #endregion

        private System.Windows.Forms.GroupBox grpbx_frage;
        private System.Windows.Forms.Label lbl_frage;
        private System.Windows.Forms.Button btn_ant_1;
        private System.Windows.Forms.TableLayoutPanel tableLayoutPanel1;
        private System.Windows.Forms.Button btn_ant_4;
        private System.Windows.Forms.Button btn_ant_3;
        private System.Windows.Forms.Button btn_ant_2;
        private System.Windows.Forms.ProgressBar pbr_stufe;
        private System.Windows.Forms.TableLayoutPanel tableLayoutPanel2;
        private System.Windows.Forms.Button btn_quelle;
        private System.Windows.Forms.Button btn_5050;
        private System.Windows.Forms.Button btn_tipp;
    }
}

